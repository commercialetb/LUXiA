import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

function sbAdmin() {
  if (!serviceKey) throw new Error("Missing SUPABASE_SERVICE_ROLE_KEY");
  return createClient(url, serviceKey);
}

// POST { projectId, areaId, conceptId }
export async function POST(req) {
  try {
    const supabase = sbAdmin();
    const body = await req.json();
    const { projectId, areaId, conceptId } = body || {};
    if (!projectId || !areaId || !conceptId) {
      return NextResponse.json({ ok:false, error:"Missing projectId/areaId/conceptId" }, { status: 400 });
    }

    // Pull project -> org + active style
    const { data: proj, error: pErr } = await supabase
      .from("projects")
      .select("id, tenant_id, active_style_id")
      .eq("id", projectId)
      .single();
    if (pErr) throw pErr;

    const tenantId = proj.tenant_id;
    let styleId = proj.active_style_id;

    // Ensure a default style exists
    if (!styleId) {
      const { data: st } = await supabase
        .from("designer_styles")
        .select("id")
        .eq("tenant_id", tenantId)
        .eq("is_default", true)
        .limit(1);

      if (st?.[0]?.id) {
        styleId = st[0].id;
        await supabase.from("projects").update({ active_style_id: styleId }).eq("id", projectId);
      } else {
        const { data: created } = await supabase
          .from("designer_styles")
          .insert({ tenant_id: tenantId, name: "Team Default", scope: "tenant", is_default: true })
          .select()
          .single();
        styleId = created.id;
        await supabase.from("projects").update({ active_style_id: styleId }).eq("id", projectId);
      }
    }

    // Load area + concept for metrics
    const { data: area, error: aErr } = await supabase
      .from("areas")
      .select("id, name, tipo_locale, superficie_m2, altezza_m")
      .eq("id", areaId)
      .single();
    if (aErr) throw aErr;

    const { data: con, error: cErr } = await supabase
      .from("concepts")
      .select("id, concept_type, solution, metrics")
      .eq("id", conceptId)
      .single();
    if (cErr) throw cErr;

    const calc = con.metrics || con.solution?.calc || {};
    const n = Number(calc.n || calc.N || 0);
    const sup = Number(area.superficie_m2 || 0);
    const density = sup ? (n / sup) : null;
    const wm2 = Number(calc.wm2 || 0);
    const ugr = Number(calc.ugr || 0);

    // Brand & CCT attempt
        const selectedBrand = (con.solution?.luminaire?.brand) || (con.solution?.brand) || null;
    const selectedCct = Number(con.solution?.cct || con.solution?.CCT || 0) || null;
    const selectedMood = con.solution?.mood || null;

    // created_by unknown here (service role), store null; team aggregation still works.
    await supabase.from("designer_learning_events").insert({
      tenant_id: tenantId,
      style_id: styleId,
      project_id: projectId,
      area_name: area.name,
      area_type: area.tipo_locale,
      selected_concept_type: con.concept_type,
      selected_brand: selectedBrand,
      selected_cct: selectedCct,
      selected_mood: selectedMood,
      n_luminaires: n,
      area_m2: sup,
      density,
      wm2,
      ugr
    });

    // recompute
    const { data: stats, error: rErr } = await supabase.rpc("recompute_designer_profile", { p_tenant_id: tenantId, p_style_id: styleId });
    if (rErr) throw rErr;

    return NextResponse.json({ ok:true, styleId, stats });
  } catch (e) {
    return NextResponse.json({ ok:false, error: e?.message || String(e) }, { status: 500 });
  }
}
